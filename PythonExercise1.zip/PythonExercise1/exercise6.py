def isLandscape(width,hieght):
    if(width>hieght):
        print("Landscape")
    else:
        print("Potrait")  

isLandscape(400,600)      