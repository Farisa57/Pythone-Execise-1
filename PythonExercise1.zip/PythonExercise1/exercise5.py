numbers=[3, 5, 1, 9, 7, 2, 8 ]
numbers.sort()
print(numbers)