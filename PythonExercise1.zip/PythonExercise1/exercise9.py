list = [ 4, 8, 7, 4,3,6,2,1,9]
i = 6

if i in list: 
    print("exist") 
else: 
    print("not exist")