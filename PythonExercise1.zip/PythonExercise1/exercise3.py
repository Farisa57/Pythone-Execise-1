def comparison(a,b):
    if(a > b):
        print(a)
    else:
        print(b)

comparison(12,32)

